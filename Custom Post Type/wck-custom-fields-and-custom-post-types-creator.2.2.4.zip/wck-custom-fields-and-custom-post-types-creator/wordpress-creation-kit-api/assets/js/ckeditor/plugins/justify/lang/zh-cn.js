﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'zh-cn', {
	block: '两端对齐',
	center: '居中',
	left: '左对齐',
	right: '右对齐'
} );
