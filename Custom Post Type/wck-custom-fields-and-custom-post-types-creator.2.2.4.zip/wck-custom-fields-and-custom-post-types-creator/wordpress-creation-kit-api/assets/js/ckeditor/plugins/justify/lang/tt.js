﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'tt', {
	block: 'Киңлеккә карап тигезләү',
	center: 'Үзәккә тигезләү',
	left: 'Сул як кырыйдан тигезләү',
	right: 'Уң як кырыйдан тигезләү'
} );
